LIMIT_ORDER_CONTRACT_ADDRESS = '0x447e489dcc2c8e4370695796cfcc30ccebe2533d510ca9abc516e6aee94f449'
LIMIT_ORDER_API_URL = 'https://order.api.fibrous.finance/api/v1/order'
